package model;

import java.util.Comparator;

public class ComparadorViajero implements Comparator<ViajeTemporal> {

    @Override
    public int compare(ViajeTemporal o1, ViajeTemporal o2) {
        return o1.getViajero().compareTo(o2.getViajero());
    }
    
}
