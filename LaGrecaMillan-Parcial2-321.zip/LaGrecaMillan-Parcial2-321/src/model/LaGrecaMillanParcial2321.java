package model;

import java.io.IOException;
import java.util.List;

public class LaGrecaMillanParcial2321 {

    public static void main(String[] args) {

        try {

            LibroDeViajes<ViajeTemporal> libro = new LibroDeViajes<>();

            libro.agregar(new ViajeTemporal(1, "Salvar a George McFly", "Marty McFly", DestinoTemporal.HILL_VALLEY_1955));
            libro.agregar(new ViajeTemporal(2, "Buscar el Almanaque Deportivo", "Marty McFly", DestinoTemporal.HILL_VALLEY_2015));
            libro.agregar(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff", "Doc Brown", DestinoTemporal.REALIDAD_ALTERNATIVA));
            libro.agregar(new ViajeTemporal(4, "Rescatar a Clara en el puente", "Doc Brown", DestinoTemporal.FAR_WEST_1885));
            libro.agregar(new ViajeTemporal(5, "Restaurar la línea temporal original", "Marty McFly", DestinoTemporal.LINEA_RESTAURADA));

            System.out.println("Viajes en el tiempo:");
            libro.paraCadaElemento(vt -> System.out.println(vt));

            System.out.println("\nViajes a 1955:");
            libro.filtrar(vt -> vt.getDestino().name().contains("1955")).forEach(System.out::println);

            System.out.println("\nViajes que contienen 'almanaque':");
            libro.filtrar(vt -> vt.getDescripcion().contains("Almanaque")).forEach(System.out::println);

            System.out.println("\nViajes ordenados por ID:");
            libro.iterator();
            libro.paraCadaElemento(System.out::println);

            System.out.println("\nViajes ordenados por descripción:");
            libro.ordenar((o1, o2) -> o1.getDescripcion().compareTo(o2.getDescripcion()));

            
            libro.guardarEnArchivo("src/data/viajes.dat");

            LibroDeViajes<ViajeTemporal> libroCargado = new LibroDeViajes<>();
            libroCargado.cargarDesdeArchivo("src/data/viajes.dat");

            System.out.println("\nViajes cargados desde archivo binario:");
            libroCargado.paraCadaElemento(System.out::println);

            libro.guardarEnCSV("src/data/viajes.csv");


        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }

    }
}


