package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class LibroDeViajes<T extends CSVSerializable> implements Iterable<T> {

    private List<T> libro = new ArrayList<>();

    // Agregar, eliminar y obtener libro por índice:
    public void agregar(T item) {
        Objects.requireNonNull(item, "Objeto nulo");
        existe(libro, item);
        libro.add(item);
    }

    public boolean eliminar(T item) {
        Objects.requireNonNull(item, "Objeto nulo");
        return libro.remove(item);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return libro.get(indice);
    }

    public int tamanio() {
        return libro.size();
    }

    // Métodos de verificación:
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }

    private void existe(List<T> lista, T item) {
        if (lista.contains(item)) {
            throw new IllegalArgumentException("El viaje ya existe en el libro");
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T item : libro) {
            if (criterio.test(item)) {
                filtrados.add(item);
            }
        }
        return filtrados;
    }

    public Iterator<T> iterator() {
        return iterator((Comparator<T>) Comparator.naturalOrder());
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        List<T> toReturn = new ArrayList<>(libro);
        if (!libro.isEmpty() && libro.getFirst() instanceof Comparable) {
            toReturn.sort(comparador);
        }
        return toReturn.iterator();
    }

    public void ordenar(Comparator<? super T> comparador) {
        libro.sort(comparador);
        for (T vt : libro) {
            System.out.println(vt);
        }
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        if (accion == null) {
            throw new NullPointerException("Esta accion es nula");
        }
        for (T vt : libro) {
            accion.accept(vt);
        }
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))) {
            if (libro.isEmpty()) {
                throw new IllegalStateException("Libro vacio ");
            }
            out.writeObject(libro);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
            libro = (List<T>) in.readObject();
        }
    }
    
    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            if (libro.isEmpty()) {
                throw new IllegalStateException("Libro vacio ");
            }
            for (T vt : libro) {
                writer.write(vt.toCSV() + "\n");
            }
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> c) throws IOException {
        try (BufferedReader bfReader = new BufferedReader(new FileReader(path))) {
            libro.clear();
            String linea;
            while ((linea = bfReader.readLine()) != null) {
                agregar(c.apply(linea));
            }
        }

    }
    
    
    
    
    

}
