package model;

import java.io.Serializable;
import java.util.Objects;
import model.CSVSerializable;
import model.DestinoTemporal;

public class ViajeTemporal implements Comparable<ViajeTemporal>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1L;
    private final int id;
    private final String descripcion;
    private final String viajero;
    private final DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "ViajeTemporal{" + "ID: " + id + " - Descripcion: " + descripcion
                + " - Viajero: " + viajero + " - Destino: " + destino;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof ViajeTemporal vt)) {
            return false;
        }
        return (this.id == vt.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public int compareTo(ViajeTemporal o) {
        return Integer.compare(this.id, o.id);
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }

    @Override
    public String toCSV() {
        return id + "," + descripcion + "," + viajero + "," + destino + '\n';
    }
    
    public static String toHeaderCSV() {
        return "id,descripcion,viajero,destino\n";
    }
    
     public static ViajeTemporal fromCSV(String viajeTemporalCSV) {
        viajeTemporalCSV = viajeTemporalCSV.substring(0, viajeTemporalCSV.length());
        String[] datos = viajeTemporalCSV.split(",");
        return new ViajeTemporal(
                Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }

}
